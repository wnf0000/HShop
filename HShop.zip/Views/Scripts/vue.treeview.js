const treeviewPlugin = {
    install: (app, options) => {
        app.component("tree-item", {
            props: {
                item: Object,
                modelValue: Object,
                name: String,
                multiful: Boolean,
            },
            emits: ["update:model-value"],
            template: `
                      <dl v-bind="$attrs" :class="!!!item.children||item.children.length==0?'tree-item no-child':'tree-item'">
                        <dd>
                        <label><input :type="multiful?'checkbox':'radio'" :value="realValue(item.value)" v-model="value" :name="name"/> {{item.text}}</label>
                        <tree-item v-if="item.children&&item.children.length>0" 
                        :multiful="multiful"
                        :class="(index==item.children.length-1 && index>0)?'last':(item.children.length==1?'only':'')" 
                        v-for="(child,index) in item.children" :item="child" :name="name" v-model="value"></tree-item>
                        </dd>
                        </dl>
                        `,
            methods: {
                realValue: function (value) {
                    switch (value) {
                        case null:
                        case undefined:
                        case NaN:
                            return null;
                        default: return value;
                    }
                }
            },
            computed: {

                value: {
                    get() {

                        return this.modelValue;
                    },
                    set(newValue) {
                        this.$emit("update:model-value", newValue);
                    },
                },
            },
        });

        app.component("tree-view", {
            props: {
                data: Array | Object,
                modelValue: Object,
                name: String,
                multiful: Boolean,
            },
            emits: ["update:model-value"],
            template: `
                      <template v-if="data instanceof Array" v-for="item in data">
                      <tree-item v-bind="$attrs" :item="item" class="treeview" :name="name" v-model="value" :multiful="multiful"></tree-item>
                      </template>
                      <template v-else>
                      <tree-item v-bind="$attrs" :item="data" class="treeview"  :name="name" v-model="value" :multiful="multiful"></tree-item>
                      </template>
                        `,
            computed: {
                value: {
                    get() {
                        return this.modelValue;
                    },
                    set(newValue) {
                        this.$emit("update:model-value", newValue);
                    },
                },
            },
            created: function () { },
        });
    },
};
