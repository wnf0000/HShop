﻿

const app = Vue.createApp({
    data() {
        return {

        }
    },
    methods: {

    }
});
app.use(validatorPlugin, {
    /* 可选的选项 */
});

app.config.globalProperties.window = window;
app.config.globalProperties.document = window.document;
app.config.globalProperties.htmlUI = window.htmlUI;
app.config.globalProperties.shortcut = window.shortcut;




var datetimePicker_html = `<input type="text" class="form-control"/>`;

app.component('datetime-picker', {
    data() {
        return {
            count: 0
        }
    },

    emits: ['dateChange'],
    //emits: {

    //    // 验证 submit 事件
    //    dateChange: (date) => { alert(date); }

    //},
    mounted() {
        this.setDateTimePick()
    },
    methods: {
        setDateTimePick() {
            let that = this

            $(that.$el).datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            }).on('changeDate', function (picker) {

                that.$emit('dateChange', picker.date?.toDateString());

            })
        },
    },
    template: datetimePicker_html
})

var layout_html = `<div>
        <app-sidemenu></app-sidemenu>
        <div id="page-wrapper" class="gray-bg">
            <app-navbar></app-navbar>
            
            <slot></slot>
        <div class="footer">
                <div class="pull-right">
                    HShop v0.1 Free.
                </div>
                <div>
                    <strong>Copyright</strong> Sunny ltd. &copy; 2022
                </div>
            </div>
        </div>
</div>
 `

app.component('app-layout', {
    data() {
        return {

        }
    },
    template: layout_html,
    created: function () {
        var store = window.localStorage || window["localStorage"];
        if (store) {
            if (store.getItem("collapse_menu") == "on") {
                document.body.setAttribute("class", "mini-navbar");
            }
        }

    }
})

var sidemenu_html = `
    <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <img alt="image" class="rounded-circle" src="img/profile_small.jpg" />
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="block m-t-xs font-bold">{{userInfo.name||userInfo.userName}}</span>
                                <span class="text-muted text-xs block">{{userInfo.roleName}} <b class="caret"></b></span>

                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
<li><a class="dropdown-item" :href="'user-view.html?id='+userInfo.id">我的资料</a></li>
<li class="dropdown-divider"></li>
                                <li><a class="dropdown-item" @click="logout">退出</a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            <img alt="image" class="rounded-circle" src="img/profile_small.jpg" />
                        </div>
                    </li>

                    <li :class="{active:(it.module.toLowerCase()==module.toLowerCase())}" v-for="(it,i) in menuItems" :title="it.text">
                        <a :id="'navmenu_'+i" :href="it.href"><i class="fa" :class="it.icon"></i> <span class="nav-label">{{it.text}}

</span>
                            <span class="fa arrow" v-if="it.subItems&&it.subItems.length>0"></span>
                        </a>
                            
                        <ul v-if="it.subItems&&it.subItems.length>0" class="nav nav-second-level collapse" :class="{in:(it.module.toLowerCase()==page.toLowerCase())}">
                                <li v-for="(sub,j) in it.subItems" :class="{active:(sub.page.toLowerCase()==page.toLowerCase())}">
                                    <a :id="'navmenu_'+i+'_'+j" :href="sub.href" :target="sub.target??'_self'">{{sub.text}}</a>
                        </ul>
                    </li>

                </ul>

            </div>
        </nav>
`;
app.component('app-sidemenu', {
    data() {
        return {
            userInfo: {},
            menuItems: [],
            fullItems: [
                {
                    href: "index.html", icon: "fa-dashboard", text: "首页", module: "index"
                },
                {
                    href: "shop.html", icon: "fa-laptop", text: "我的店铺", module: "shop", controller: "ShopController", action: "GetMyShop", actionId: "AC9D73E3-6D02-48ED-AC3F-9880CC59AFFD"

                },
                
                {
                    href: "#", icon: "fa-truck", text: "订单管理", module: "order", controller: "OrderController", action: null, actionId: "623EC392-84AE-49D0-92DC-E175C51F6FA7",
                    subItems: [
                        {
                            href: "order.html", text: "全部订单", module: "order", page: "order", controller: "OrderController", action: "GetOrders", actionId: "397B3872-F331-43FF-8FA9-040CE3B9FCCE"
                        },
                        {
                            href: "order-new.html", text: "待确认订单", module: "order", page: "order-new", controller: "OrderController", action: "GetOrders", actionId: "1D677559-F88B-48BE-BDE6-7D1C7E1D3678"
                        },
                        {
                            href: "order-confirmed.html", text: "待发货订单", module: "order", page: "order-confirmed", controller: "OrderController", action: "GetOrders", actionId: "C50ED050-1DD0-4C48-A8C8-0F9476F28B8D"
                        },
                        {
                            href: "order-sent.html", text: "已发货订单", module: "order", page: "order-sent", controller: "OrderController", action: "GetOrders", actionId: "7C9B11F9-C403-478F-802E-916A368865A0"
                        },
                        {
                            href: "order-canceled.html", text: "已取消订单", module: "order", page: "order-canceled", controller: "OrderController", action: "GetOrders", actionId: "8AAACE63-3A0D-4D2E-91B7-695BA60BB8D7"
                        },
                        {
                            target: "_blank", href: "order-create.html", text: "创建订单", module: "order", page: "order-create", controller: "OrderController", action: "GetOrders", actionId: "72FE207F-1EEB-424B-9C64-FA087D3D923E"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-diamond", text: "商品管理", module: "product", controller: "ProductController", action: null, actionId: "5ED5D27A-B9DF-4FA8-8A17-DAB76D32A6C6",
                    subItems: [
                        {
                            href: "product.html", text: "商品列表", module: "product", page: "product", controller: "ProductController", action: "GetProducts", actionId: "5242EF2A-8625-40BB-A229-D909E83ECC17"
                        },
                        {
                            target: "_blank", href: "product-create.html", text: "创建商品", module: "product", page: "product-create", controller: "ProductController", action: "Create", actionId: "25C8B279-4F59-40D8-A69C-598AFD582332"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-folder-open-o", text: "分类管理", module: "catalog", controller: "CatalogController", action: null, actionId: "5ED5D27A-B9DF-4FA8-8A17-DAB76D32A6C6",
                    subItems: [
                        {
                            href: "catalog.html", text: "分类列表", module: "catalog", page: "catalog", controller: "CatalogController", action: "GetCatalogs", actionId: "5242EF2A-8625-40BB-A229-D909E83ECC17"
                        },
                        {
                            target: "_blank", href: "catalog-create.html", text: "创建分类", module: "catalog", page: "catalog-create", controller: "CatalogController", action: "Create", actionId: "25C8B279-4F59-40D8-A69C-598AFD582332"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-tasks", text: "类型管理", module: "productType", controller: "ProductTypeController", action: null, actionId: "5F7182C0-8FBC-4C8F-85BD-042B83CBCCE4",
                    subItems: [
                        {
                            href: "productType.html", text: "类型列表", module: "productType", page: "productType", controller: "ProductTypeController", action: "GetModels", actionId: "CF8CEEE3-3D60-42B3-9B59-2F3710A0C280"
                        },
                        {
                            target: "_blank", href: "productType-create.html", text: "创建类型", module: "productType", page: "productType-create", controller: "ProductTypeController", action: "Create", actionId: "D3D4B40F-AFBC-45BD-B6B5-C8F4C08FABFD"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-align-left", text: "规格管理", module: "specs", controller: "SpecsController", action: null, actionId: "A6D0B562-7719-4B7C-82D8-A555C610C517",
                    subItems: [
                        {
                            href: "specs.html", text: "规格列表", module: "specs", page: "specs", controller: "SpecsController", action: "GetSpecses", actionId: "FC1567C3-7360-4FB4-918F-464E01115FAF"
                        },
                        {
                            target: "_blank", href: "specs-create.html", text: "创建规格", module: "specs", page: "specs-create", controller: "SpecsController", action: "Create", actionId: "73373B04-412B-4D5B-AC4C-66133A6F4884"
                        }

                    ]
                },
                
                
                {
                    href: "#", icon: "fa-vcard-o", text: "客户管理", module: "customer", controller: "CustomerController", action: null, actionId: "7C1612A0-FCB3-44E3-ADBC-ADE90F7A62ED",
                    subItems: [
                        {
                            href: "customer.html", text: "客户列表", module: "customer", page: "customer", controller: "CustomerController", action: "GetCustomers", actionId: "36171934-4444-4F6D-A8D8-90B9EC067CBD"
                        },
                        {
                            target: "_blank", href: "customer-create.html", text: "创建客户", module: "customer", page: "customer-create", controller: "CustomerController", action: "Create", actionId: "55134E0C-A7F5-4E1E-9BA1-C280232316D3"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-user", text: "用户管理", module: "user", controller: "UserController", action: null, actionId: "D2F2C5CB-C50A-474E-ABD5-0AA96C33771C",
                    subItems: [
                        {
                            href: "user.html", text: "用户列表", module: "user", page: "user", controller: "UserController", action: "GetUsers", actionId: "2CBABA9F-5D4A-4692-AEDD-057CE234DFA0"
                        },
                        {
                            target: "_blank", href: "user-create.html", text: "创建用户", module: "user", page: "user-create", controller: "UserController", action: "Create", actionId: "C53FE4AD-9421-4E35-840F-FB57764AE97D"
                        }

                    ]
                },
                {
                    href: "#", icon: "fa-lastfm", text: "角色管理", module: "role", controller: "RoleController", action: null, actionId: "33932839-AA06-4167-A443-F7D0451FA076",
                    subItems: [
                        {
                            href: "role.html", text: "角色列表", module: "role", page: "role", controller: "RoleController", action: "GetRoles", actionId: "9DCC35B6-067B-4772-86CC-36E2CC1425E1"
                        },
                        {
                            target: "_blank", href: "role-create.html", text: "创建角色", module: "role", page: "role-create", controller: "RoleController", action: "Create", actionId: "A7C4747E-E10F-4747-A349-D22F9B5F8B5B"
                        }

                    ]
                },
                {
                    href: "action.html", icon: "fa-ils", text: "权限管理", module: "action", controller: "ActionController", action: "GetActions", actionId: "1D3F4A0C-8705-445D-8C46-E4BC667785A4"
                },
                {
                    href: "#", icon: "fa-plane", text: "快递方式管理", module: "deliveryMethod", controller: "DeliveryMethodController", action: null, actionId: "12FB003C-1C4B-4D9C-80BF-659C62A6B7AD",
                    subItems: [
                        {
                            href: "deliveryMethod.html", text: "快递方式列表", module: "deliveryMethod", page: "deliveryMethod", controller: "DeliveryMethodController", action: "GetDeliveryMethods", actionId: "6EF68420-6794-47CE-90A1-C5C3BA68730F"
                        },
                        {
                            target: "_blank", href: "deliveryMethod-create.html", text: "创建快递方式", module: "deliveryMethod", page: "deliveryMethod-create", controller: "DeliveryMethodController", action: "Create", actionId: "6400D5D5-7814-4BE7-BF1C-FC8BD0AB12E0"
                        }

                    ]
                },
                {
                    href: "settings.html", icon: "fa-gears", text: "系统参数管理", module: "settings", controller: "SettingsController", action: "GetSettingses", actionId: "B1D70723-82A5-4334-8B11-8502EF435F3F"

                },
                
                {
                    href: "district.html", icon: "fa-podcast", text: "行政区跨管理", module: "district", controller: "DistrictController", action: "GetModels", actionId: "42BECCD2-9235-418C-B5E9-7B95FAC11DFD"
                }

            ],
            module: null,
            page: null
        }
    },
    methods: {
        getUserInfo: function () {
            return htmlUI.invokeAction("LoginController", "GetUserInfo", {})
                .then(data => { this.userInfo = data.result.data; return data.result.data; });
        },

        logout: function () {
            htmlUI.invokeAction("LoginController", "Logout", {}).then(rtn => {
                window.location.href = "login.html";
            });
        }
    },
    template: sidemenu_html,
    created: function () {

        function GetFilename() {
            var url = location.href;
            if (url) {
                var m = url.toString().match(/.*\/(.+?)\./);
                if (m && m.length > 1) {
                    return m[1];
                }
            }
            return "";
        }
        var filename = GetFilename();
        this.module = filename.split('-')[0];
        this.page = filename;

        htmlUI.invokeAction("MenuController", "GetMenuList").then(r => {
            this.menuItems = r.result.data;
            htmlUI.raiseEvent("menu-loaded", null);
        })

        this.getUserInfo().then(userInfo => {

        });
    }
})

var navbar_html = `<div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                        <form role="search" class="navbar-form-custom" method="post" action="#">
                            <div class="form-group" id="tipsCtn">
                               <a class="tips form-control"><i class='fa fa-lightbulb-o'></i>欢迎使用小店管理系统</a>
                            </div>
                        </form>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li><a onclick="pageSnap()"><i class="fa fa-camera"></i>截屏{{shortcut.snap?.keyqu}}</a></li>
                        <li>
                           <a> 时钟 <i class="fa fa-clock-o" ></i> <span id="clock" class="m-r-sm text-muted welcome-message">{{htmlUI.tools.formateDateTime(new Date(),'yyyy-MM-dd HH:mm:ss')}}</span></a>
                        </li>
                        
                        <li>
                            <a @click="logout">
                                <i class="fa fa-sign-out"></i> 退出
                            </a>
                        </li>
                    </ul>
<slot></slot>
                </nav>
            </div>


`;

app.component('app-navbar', {
    data() {
        return {
            //shortcut: window.shortcut
        }
    },
    methods: {
        logout: function () {
            htmlUI.invokeAction("LoginController", "Logout", {}).then(rtn => {
                window.location.href = "login.html";
            });
        }
    },
    template: navbar_html,
    created: function () {
        shortcut.addShortcut("snap", [shortcut.cmdKey.alt, shortcut.cmdKey.shift], ["p"]).on = window.pageSnap;


    }
})

var breadcrumb_html = `<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-8">
                    <h2>{{title}}</h2>
                    <ol class="breadcrumb">

                        <li class="breadcrumb-item" v-for="(item, index) in anchors" :key="item.id">

                            <strong v-if="(index+1)==anchors.length">{{item.text}}</strong>
                            <a v-else v-bind:href="item.src">{{item.text}}</a>
                            
                        </li>
                        
                    </ol>
                </div>
                <div class="col-lg-4">
                <p style="margin-top:30px">
                <slot></slot>
                </p>
                </div>
            </div>`
app.component('app-breadcrumb', {
    data() {
        return {
        }
    },
    /*inject: ['shortcut'],*/
    props: { title: String, anchors: Array },
    template: breadcrumb_html
})

var content_html = `<div class="wrapper wrapper-content animated fadeInRight">

                <slot></slot>
            </div>
            `;
app.component('app-content', {
    data() {
        return {
            //count: 0
        }
    },

    template: content_html
})
app.component("app-pagination", {
    inject: ['listModel'],
    data: function () {
        return {
            shortcutTop: shortcut.addShortcut("shortcutTop", ["alt"], ["arrowup"]).withOn(this.moveTop).key,
            shortcutEnd: shortcut.addShortcut("shortcutEnd", ["alt"], ["arrowdown"]).withOn(this.moveEnd).key,
            shortcutPrev: shortcut.addShortcut("shortcutPrev", ["alt"], ["arrowleft"]).withOn(this.movePrev).key,
            shortcutNext: shortcut.addShortcut("shortcutNext", ["alt"], ["arrowright"]).withOn(this.moveNext).key,

        }
    },
    computed: {
        numbers() {
            return computeNumbers(this.listModel.list.pageCount, this.listModel.list.index);
        }


    },
    template: `<div>
<select v-model="this.listModel.list.size" class="form-control float-left" @change="get" style="width:280px">
                                                <option value="10">每页10条记录</option>
                                                <option value="20">每页20条记录</option>
                                                <option value="50">每页50条记录</option>
                                            </select>
<ul class="pagination float-right">
                                                <li><a data-page="first" @click="getPage(1)" href="#first">首页(<span v-if="icon" v-html="icon"></span>{{shortcutTop}})</a>  </li>
                                                <li><a @click="movePrev()">上页(<span  v-if="icon" v-html="icon"></span>{{shortcutPrev}})</a>  </li>
                                                <li v-for="num in numbers" :class="{'footable-page':true,active:active(num)}" >
                                                    <a @click="getPage(num)">
                                                        {{num}}
                                                    </a>
                                                </li>

                                                <li><a @click="moveNext()">下页(<span  v-if="icon" v-html="icon"></span>{{shortcutNext}})</a></li>
                                                <li><a data-page="last" @click="moveEnd()" href="#last">末页(<span  v-if="icon" v-html="icon"></span>{{shortcutEnd}})</a></li>
                                                <li><a>共({{this.listModel.list.pageCount}})页</a></li>
                                            </ul></div>`,
    methods: {
        get: function () { this.listModel.get() },
        getPage: function (index) { this.listModel.getPage(index) },
        movePrev: function () { this.listModel.movePrev() },
        moveNext: function () { this.listModel.moveNext() },
        active: function (num) { return this.listModel.active(num) },
        moveEnd: function () { this.listModel.getPage(this.listModel.list.pageCount) },
        moveTop: function () { this.listModel.getPage(1) }
    },
    created: function () {
        let _this = this;
        this.listModel.onListLoaded = function () {

            for (var i = 1; i <= _this.listModel.list.pageCount; i++) {
                shortcut.addOrReplaceSubsetShortcut("shortcutGetpage_" + i, ['alt'], i.toString()).withOn(cmd => {
                    _this.getPage(Number.parseInt(cmd.normalKeys.join('')))

                })
            }
        }
    }
})
app.component("app-orderstatus", {
    data() {
        return {
        }
    },
    props: { status: String },

    template: `<span v-if="status=='待确认'" class="label label-warning">{{status}}</span>
                                        <span v-else-if="status=='已确认'" class="label label-success">{{status}}</span>
                                        <span v-else-if="status=='已取消'" class="label label-danger">{{status}}</span>
                                        <span v-else-if="status=='发货中'" class="label label-info">{{status}}</span>
                                        <span v-else-if="status=='已发货'" class="label label-primary">{{status}}</span>
                                        <span v-else class="label label-default">{{status}}</span>
    `
});
app.component('app-qrcode', {
    data() {
        return {
            image: null,
        }
    },
    props: { content: String },

    computed: {
        alt() {
            if (this.content) {
                htmlUI.invokeAction("QRCodeController", "GenerateQRCode", { data: this.content }).then(rtn => {

                    this.image = "data:image/png;base64," + rtn.result.data;
                });
            }

            return this.content;
        }
    },
    template: `<img :src='image' :alt='alt'/>`,

})
app.component('app-barcode', {
    data() {
        return {
            image: null,
        }
    },
    props: { content: String },

    computed: {
        alt() {
            if (this.content) {
                htmlUI.invokeAction("QRCodeController", "GenerateBarCode", { data: this.content }).then(rtn => {

                    this.image = "data:image/png;base64," + rtn.result.data;
                });
            }
            return this.content;
        }
    },
    template: `<img :src='image' :alt='alt'/>`,

})


