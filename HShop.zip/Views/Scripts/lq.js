﻿(function () {

    function checkFunction(func) {
        if (!isFunction(func))
            throw "参数类型不是function错误";
    }
    function checkArray(data) {
        if (!isArray(data))
            throw "参数类型不是Array错误";
    }
    function isNumber(value) {
        return typeof value == 'number';
    }
    function isArray(data) {
        return data instanceof Array;
    }
    function isFunction(func) {
        return typeof func == "function";
    }
    var Queryable = function (data) {
        checkArray(data);
        var _data = [];
        var _self = this;
        if (isArray(data)) {
            _data = data;
        }
        else {
            throw "Queryable不支持非数组类型";
        }

        //循环执行
        _self.forEach = function (func) {
            for (var i = 0; i < _data.length; i++) {
                if (func(_data[i], i) === true) break;
            }
        }
        //求和
        _self.sum = function (selector) {
            checkFunction(selector);
            var s = 0;
            this.forEach(x => {
                if (isNumber(v = selector(x))) {
                    s += v;
                }
            });
            return s;
        }
        //求最大值
        _self.max = function (selector) {
            checkFunction(selector);
            var max = NaN;
            this.forEach(x => {
                var v = selector(x)
                max = max > v ? max : (max = v);
            });
            return max;
        }
        //求最小值
        _self.min = function (selector) {
            checkFunction(selector);
            var min = NaN;
            this.forEach(x => {
                var v = selector(x)
                min = min < v ? min : (min = v);
            });
            return min;
        }
        //求平均值
        _self.averate = function (selector) {

            checkFunction(selector);
            if (_data.length == 0) return Number.NaN;
            var sum = this.sum(selector);
            return sum / _data.length;

        }
        //查询符合条件的元素集合
        _self.where = function (selector) {
            checkFunction(selector);
            var arrry = [];
            this.forEach(x => {
                if (selector(x)) {
                    arrry.push(x);
                }
            });
            return new Queryable(arrry);
        }
        //转为数组
        _self.toArray = function () {
            return _data;
        }
        //在指定索引的元素
        _self.elementAt = function (index) {
            return _data[index];
        }
        //元素索引
        _self.indexOf = function (elm) {
            return _data.indexOf(elm);
        }

        //返回符合条件的首元素，无符合条件则返回undefined
        _self.firstOrDefault = function (selector) {
            checkFunction(selector);
            var one = undefined;
            this.forEach(x => {
                if (selector(x)) {
                    one = x;
                    return true;
                }
            });
            return one;
        }
        //返回符合条件的末元素，无符合条件则返回undefined
        _self.lastOrDefault = function (selector) {
            checkFunction(selector);

            for (var i = _data.length - 1; i >= 0; i--) {
                if (selector(_data[i])) {
                    return _data[i];
                }
            }
            return undefined;
        }
        //查找一个元素
        _self.findOne = function (selector) {
            checkFunction(selector);
            var one = undefined;
            this.forEach(x => {
                if (selector(x)) {
                    one = x;
                    return true;
                }
            });
            return one;
        }
        //查找符合条件的元素并返回新的集合
        _self.select = function (selector) {
            checkFunction(selector);

            var array = [];
            this.forEach(item => {
                array.push(selector(item));
            });
            return new Queryable(array);
        }
        //升序排序
        _self.orderBy = function (selector) {
            checkFunction(selector);
            var compare = function (a, b) {
                return selector(a) > selector(b) ? 1 : -1;
            }

            _data.sort(compare);
            return this;
        }
        //降序排序
        _self.orderByDesc = function (selector) {
            checkFunction(selector);
            var compare = function (a, b) {
                return selector(a) > selector(b) ? -1 : 1;
            }
            _data.sort(compare);
            return this;
        }
        //判断是否全部元素满足条件
        _self.all = function (predicate) {

            checkFunction(predicate);
            for (let item of _data) {
                if (predicate(item) === false) return false;
            }
            return true;

        }
        //判断是否有元素满足条件
        _self.any = function (predicate) {

            checkFunction(predicate);
            for (let item of _data) {
                if (predicate(item)) return true;
            }
            return false;

        }
        //加入元素
        _self.add = function (item) {

            _data.push(item);
            return this;

        }
        //加入多个元素
        _self.addRange = function (array) {
            for (let item of array) {
                _data.push(item);
            }

            return this;
        }
        //删除元素
        _self.remove = function (item) {
            var index = this.indexOf(item);
            if (index > -1) {
                _data.splice(index, 1);
            }
            return this;
        }
        //删除元素根据选择器结果删除元素
        _self.removeBy = function (selector) {
            checkFunction(selector);
            this.where(selector).forEach(x => this.remove(x));
            return this;
        }
        //加入元素，如果已存在则更新元素
        _self.addOrUpdate = function (item) {
            var index = this.indexOf(item);
            if (index > -1) _data[index] = item;
            else {
                this.add(item);
            }
            return this;
        }
        //求满足条件元素数量
        _self.count = function (selector) {
            if (arguments.length == 0) {
                return _data.length;
            }
            checkFunction(selector);
            var count = 0;
            this.forEach(x => {
                if (selector(x)) count++;
            });
            return count;
        }
        //排重
        _self.distinctBy = function (keySelector) {
            checkFunction(keySelector);
            const array = [];
            const map = new Map()
            this.forEach(item => {
                var val = keySelector(item);
                if (!map.has(val)) {
                    map.set(val, true)
                    array.push(item);
                }
            })
            _data = array;
            return this;
        }
        //求与set2的差,set2可以是数组或者Linq，selector1是linq选择器，selector2是set2元素选择器
        _self.exceptBy = function (set2, selector1, selector2) {
            let linq2;
            if (isArray(set2)) {
                linq2 = set2.toLinq();
            } else if (set2 instanceof Queryable) {
                linq2 = set2;
            }
            else {
                throw "参数set2应该为数组或者Linq";
            }
            checkFunction(selector1);
            checkFunction(selector2);
            this.removeBy(x => {
                return linq2.any(y => selector2(y) == selector1(x));
            })
            return this;
        }
        //求交集
        _self.intersectBy = function (set2, selector1, selector2) {
            let linq2;
            if (isArray(set2)) {
                linq2 = set2.toLinq();
            } else if (set2 instanceof Queryable) {
                linq2 = set2;
            }
            else {
                throw "参数set2应该为数组或者Linq";
            }
            checkFunction(selector1);
            checkFunction(selector2);
            this.removeBy(x => {
                return !linq2.any(y => selector2(y) == selector1(x));
            })

            return this;
        }
    }


    window.Linq = {

        from: function (data) {
            return new Queryable(data);
        }
    }
    Array.prototype.toLinq = function () {
        return Linq.from(this);
    }
})();
