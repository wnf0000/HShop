﻿document.writeln(`<link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/plugins/footable/footable.core.css" rel="stylesheet">
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">`);
document.writeln(`<script src="Scripts/jquery-3.1.1.min.js"></script>`);
document.writeln(`<script src="Scripts/popper.min.js"></script>`);
document.writeln(`<script src="Scripts/bootstrap.min.js"></script>`);
document.writeln(`<script src="Scripts/inspinia.js"></script>`);
document.writeln(`<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>`);
document.writeln(`<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>`);
document.writeln(`<script src="js/plugins/pace/pace.min.js"></script>`);
document.writeln(`<script src="js/plugins/toastr/toastr.min.js"></script>`);
document.writeln(`<script src="js/plugins/footable/footable.all.min.js"></script>`);
document.writeln(`<script src="js/plugins/sweetalert/sweetalert.min.js"></script>`);


(function (w) {
    w.pageSnap = function () {
        htmlUI.native.PageSnap(document.body.clientWidth, document.body.clientHeight, window.innerWidth, window.innerHeight);
    }
    w.computeNumbers = (pageCount, index, numberCount = 8) => {
        let stage = Math.floor(index / numberCount);
        var ar = []
        if (index % numberCount != 0) {
            if ((stage + 1) * numberCount <= pageCount) {
                for (i = stage * numberCount + 1; i <= (stage + 1) * numberCount; i++) {
                    ar.push(i);
                }
            }
            else {
                for (i = (pageCount - numberCount < 1 ? 1 : pageCount - numberCount+1); i <= pageCount; i++) {
                    ar.push(i);
                }
            }
        }
        else {
            if ((stage) * numberCount <= pageCount) {
                for (i = (stage - 1) * numberCount + 1; i <= (stage) * numberCount; i++) {
                    ar.push(i);
                }
            }
            else {
                for (i = (pageCount - numberCount < 1 ? 1 : pageCount - numberCount + 1); i <= pageCount; i++) {
                    ar.push(i);
                }
            }
            
        }
        return ar;
    }
    w.isLastMonth = function (date) {
        var val = new Date(date);
        var lastMonth = new Date().addMonths(-1);
        return val.getFullYear() == lastMonth.getFullYear() && val.getMonth() == lastMonth.getMonth();
    }
    w.isThisMonth = function (date) {
        var val = new Date(date);
        var thisMonth = new Date();
        return val.getFullYear() == thisMonth.getFullYear() && val.getMonth() == thisMonth.getMonth();
    }
    w.isYesterday = function (date) {
        var val = new Date(date);
        var yesterday = new Date().addDays(-1);
        return val.getFullYear() == yesterday.getFullYear() && val.getMonth() == yesterday.getMonth() && val.getDate() == yesterday.getDate();
    }
    w.isToday = (date) => {
        var val = new Date(date);
        var today = new Date();
        return val.getFullYear() == today.getFullYear() && val.getMonth() == today.getMonth() && val.getDate() == today.getDate();
    }
    Date.prototype.isLastMonth = function () {
        var val = this;
        var lastMonth = new Date().addMonths(-1);
        return val.getFullYear() == lastMonth.getFullYear() && val.getMonth() == lastMonth.getMonth();
    }
    Date.prototype.isThisMonth = function () {
        var val = this;
        var thisMonth = new Date();
        return val.getFullYear() == thisMonth.getFullYear() && val.getMonth() == thisMonth.getMonth();
    }
    Date.prototype.isToday = function () {
        var val = this;
        var today = new Date();
        return val.getFullYear() == today.getFullYear() && val.getMonth() == today.getMonth() && val.getDate() == today.getDate();
    }
    Date.prototype.isYesterday = function () {
        var val = this;
        var yesterday = new Date().addDays(-1);
        return val.getFullYear() == yesterday.getFullYear() && val.getMonth() == yesterday.getMonth() && val.getDate() == yesterday.getDate();
    }
    Date.prototype.addYears = function (years) {
        var years = Number.parseInt(years);
        var d = new Date(this);
        d.setFullYear(d.getFullYear() + years);
        return d;
    }
    Date.prototype.addMonths = function (months) {
        months = Number.parseInt(months);
        var d = new Date(this);
        var years = Number.parseInt(months / 12);
        var leftMonth = months % 12;
        var month = d.getMonth() + leftMonth;
        d.setFullYear(d.getFullYear() + years);
        d.setMonth(month);
        return d;
    }
    Date.prototype.addDays = function (days) {
        return new Date(this.getTime() + days * 86400000);
    }
    Date.prototype.addHours = function (hours) {
        return new Date(this.getTime() + hours * 3600000);
    }
    Date.prototype.addMinutes = function (minutes) {
        return new Date(this.getTime() + minutes * 60000);
    }
    Date.prototype.addSeconds = function (seconds) {
        return new Date(this.getTime() + seconds * 1000);
    }
    Date.prototype.addMilliseconds = function (milliseconds) {
        return new Date(this.getTime() + milliseconds);
    }

    w.copyProps = function (src, dest) {
        for (prop in dest) {
            dest[prop] = src[prop];
        }
    }
})(window);

window.onload = () => {
    shortcut.cancel.addListener(() => {
        if (confirm("确定关闭本窗口吗？")) {
            htmlUI.native.CloseWindow();
        }
    });
    shortcut.addShortcut("nextTap", ['ctrl'], ['ArrowRight']).on = async function () {
        await htmlUI.native.SelectTab("next")
    }
    shortcut.addShortcut("prevTap", ['ctrl'], ['ArrowLeft']).on = async function () {
        await htmlUI.native.SelectTab("prev")
    }
    shortcut.addShortcut("topTap", ['ctrl'], ['ArrowUp']).on = async function () {
        await htmlUI.native.SelectTab("top")
    }
    shortcut.addShortcut("bottomTap", ['ctrl'], ['ArrowDown']).on = async function () {
        await htmlUI.native.SelectTab("bottom")
    }
}

