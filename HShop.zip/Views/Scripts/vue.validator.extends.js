(function (vld) {
    //最小长度
    validator.extends("minLength", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}长度不能少于${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);
        var len = value.length ?? 0;
        return len >= rule.options.value;
    });
    //最大长度
    validator.extends("maxLength", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}长度不能超过${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);
        var len = value.length ?? 0;
        return len <= rule.options.value;
    });
    //小于
    validator.extends("lt", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}应该小于${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);

        return value < rule.options.value;
    });
    //大于
    validator.extends("gt", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}应该大于${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);

        return value > rule.options.value;
    });
    //最小值-大于等于
    validator.extends("min", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}应该大于等于${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);

        return value >= rule.options.value;
    });
    //最大值-小于等于
    validator.extends("max", function (value, rule) {
        var defaultErrMessageTemplate = "${alias}应该小于等于${value}";
        rule.adjustErrMessageTemplate(defaultErrMessageTemplate);

        return value <= rule.options.value;
    });
    
})();
