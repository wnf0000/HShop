﻿

app.mount('#wrapper');
var elm;
htmlUI.addBroacastListener("ClockBroadcaster", function (event) {

    elm = elm || document.getElementById("clock");
    (elm || {}).innerText = event.data.data;
});

htmlUI.addBroacastListener("TipsBroadcaster", function (event) {
    console.log(event.data)
    let tipsCtn = $("#tipsCtn");
    let lastTip = $("a:first", tipsCtn).get(0);

    if (lastTip) {
        lastTip = $(lastTip);
        lastTip.fadeOut("fast", () => {
            lastTip.remove();
            let tip = $(`<a class="tips form-control animated"><i class='fa fa-lightbulb-o'></i> ` + event.data.data + `</a>`);
            tipsCtn.append(tip);
            tip.addClass("slideInDown");
        })
    }
    else {
        let tip = $(`<a class="tips form-control animated"><i class='fa fa-lightbulb-o'></i> ` + event.data.data + `</a>`);
        tipsCtn.append(tip);
        tip.addClass("slideInDown");
    }
    
});

htmlUI.addEventListener("SYS_Event", async function (event) {

    setTimeout(function () {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            showMethod: 'slideDown',
            timeOut: 4000
        };
        toastr.error(event.data.description, '系统提示');

    }, 100);
    
});
htmlUI.addEventListener("menu-loaded", (event) => {
    
    setTimeout(() => {
        // MetisMenu
        var sideMenu = $('#side-menu').metisMenu();

        sideMenu.on('shown.metisMenu', function (e) {
            fix_height();
        });
    }, 100);
    
})

function showToast(status, message, title = '系统提示') {
    if (status) {
        setTimeout(function () {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 4000
            };
            toastr.success(message, title);

        }, 100);
    }
    else {
        setTimeout(function () {
            toastr.options = {
                closeButton: true,
                progressBar: true,
                showMethod: 'slideDown',
                timeOut: 4000
            };
            toastr.error(message, title);

        }, 100);
    }
}
