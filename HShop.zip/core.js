﻿(function () {

    var htmlUI = htmlUI || {};
    htmlUI.__defineGetter__('VueSupported', function () { return !!window.Vue; });
    Object.defineProperty(htmlUI, 'version', {
        value: '1.0b',
        writable: false,
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(htmlUI, 'Sys_Event_Type', {
        value: 'SYS_Event',
        writable: false,
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(htmlUI, 'Broadcast_Event_Type', {
        value: 'Broadcast',
        writable: false,
        enumerable: true,
        configurable: true
    });

    


    htmlUI.native = window.chrome.webview.hostObjects.native;

    htmlUI.postMessage = window.chrome.webview.postMessage;

    htmlUI.invokeAction = async function (controller, action, parameterObject = null, notifyListener = undefined) {

        var postData = {
            webViewGuid: await this.native.GetWebViewGuid(),
            controller,
            action,
            data: parameterObject,
            listenerkey: null
        }
        var listenerName = null;
        if (typeof notifyListener == 'function') {
            listenerName = 'T_' + await this.native.NewGuid();
            (this.listeners = this.listeners || {})[listenerName] = notifyListener;
            postData.listenerkey = listenerName;
        }
        return this.native.SolveMessage(JSON.stringify(postData)).then(data => { return JSON.parse(data) }).catch(e => { console.log(e); });

    }


    htmlUI.addEventListener = function (eventType, listener) {
        document.addEventListener(eventType, listener);
    }
    htmlUI.removeEventListener = function (eventType, listener) {
        document.removeEventListener(eventType, listener);
    }
    htmlUI.raiseEvent = function (eventType, dataObj) {
        var evt = document.createEvent('HTMLEvents');
        evt.initEvent(eventType, true, true);
        evt.data = dataObj;
        document.dispatchEvent(evt);
    }
    htmlUI.addMessageListener = function (listener) {
        window.chrome.webview.addEventListener('message', listener);
    }
    htmlUI.removeMessageListener = function (listener) {
        window.chrome.webview.removeEventListener('message', listener);
    }

    htmlUI.addBroacastListener = function (broadcastType, listener) {
        var eventType = htmlUI.Broadcast_Event_Type + "_" + broadcastType;
        this.addEventListener(eventType, listener);
        this.addEventListener(null);
    }
    htmlUI.addSysEventListener = function (listener) {
        const eventType = htmlUI.Sys_Event_Type;
        this.addEventListener(eventType, listener);
    }

    //工具
    htmlUI.tools = {
        emptyGuid: '00000000-0000-0000-0000-000000000000',
        padLeft: function (str, len, char) {
            var s = str + '';
            for (; s.length < len;) {
                s = char + s;
            }
            return s;
        },
        padRight: function (str, len, char) {
            var s = str + '';
            for (; s.length < len;) {
                s += char;
            }
            return s;
        },
        formateDateTime: function (dateTime, fmtStr) {
            dateTime = new Date(dateTime);
            var o = {
                'yyyy': dateTime.getFullYear(),
                'yy': (dateTime.getFullYear() + '').substr(2),

                'MM': this.padLeft(dateTime.getMonth() + 1, 2, '0'),
                'M': dateTime.getMonth() + 1,                 //月份 

                'dd': this.padLeft(dateTime.getDate(), 2, '0'),
                'd': dateTime.getDate(),                    //日 

                'hh': this.padLeft(dateTime.getHours() % 12, 2, '0'),
                'h': dateTime.getHours() % 12,                   //12小时制1-2位

                'HH': this.padLeft(dateTime.getHours(), 2, '0'),
                'H': dateTime.getHours(),                   //24小时制1-2位

                'mm': this.padLeft(dateTime.getMinutes(), 2, '0'),                 //分 2位
                'm': dateTime.getMinutes(),                 //分 1-2位

                'ss': this.padLeft(dateTime.getSeconds(), 2, '0'),                 //秒 2位
                's': dateTime.getSeconds(),                 //秒 

                'q+': Math.floor((dateTime.getMonth() + 3) / 3), //季度 
                'f+': dateTime.getMilliseconds()             //毫秒 
            };

            for (var k in o) {
                if (new RegExp('(' + k + ')').test(fmtStr)) {
                    fmtStr = fmtStr.replace(RegExp.$1, o[k]);
                }
            }
            return fmtStr;
        },
        getQueryString: function (name) {
            var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
            var r = window.location.search.substr(1).match(reg);
            var context = '';
            if (r != null)
                context = r[2];
            reg = null;
            r = null;
            return context == null || context == '' || context == 'undefined' ? '' : context;
        },
        closeWindow: function () {
            if (confirm("确定关闭本窗口吗？")) {
                htmlUI.native.CloseWindow();
            }
        }
    };

    window.htmlUI = htmlUI;
})();




